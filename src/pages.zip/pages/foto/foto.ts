import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { File } from '@ionic-native/file';
import { FilePath } from '@ionic-native/file-path';
import { Http, Headers, RequestOptions } from '@angular/http';
import { FileChooser } from '@ionic-native/file-chooser';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
import { AlertController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { LoadingController } from 'ionic-angular';
import { Storage } from '@ionic/storage';


/**
 * Generated class for the FotoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-foto',
  templateUrl: 'foto.html',
})
export class FotoPage {

 img1: any = "icon_camera.png";
 img2: any = "icon_camera.png";
 img3: any = "icon_camera.png";
 img4: any = "icon_camera.png";
 img5: any = "icon_camera.png";
 img6: any = "icon_camera.png";
 img7: any = "icon_camera.png";
 nama_foto: any= "-";
 path: any;
 nik: any = "955139";
 deg1: any = "90deg";
 nama_file: any;
 isian: any = 'nok';
 pilihan: any;
 loader: any;


 lat_1: any;
 lat_2: any;
 lat_3: any;
 lat_4: any;
 lat_5: any;
 lat_6: any;
 lat_7: any;

 long_1: any;
 long_2: any;
 long_3: any;
 long_4: any;
 long_5: any;
 long_6: any;
 long_7: any;

 date_1: any;
 date_2: any;
 date_3: any;
 date_4: any;
 date_5: any;
 date_6: any;
 date_7: any;

 name_1: any;
 name_2: any;
 name_3: any;
 name_4: any;
 name_5: any;
 name_6: any;
 name_7: any;

 latitude: any;
 longitude: any;
 date_new: any;


  constructor(public navCtrl: NavController,
   private fileChooser: FileChooser,
   public TransferObject: FileTransferObject,
   private transfer: FileTransfer,
   public loadingCtrl: LoadingController,
   private geolocation: Geolocation,
   public alertCtrl: AlertController,

   public navParams: NavParams,private camera: Camera
  	,private file: File,
  	public http: Http,
  	private filePath: FilePath
  	){
  		this.showConfirm();
  		var date = new Date();

        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var day = date.getDate();
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();
        var millisecond = date.getMilliseconds();

        this.geolocation.getCurrentPosition().then((resp) => {
		 // resp.coords.latitude
		 // resp.coords.longitude
		 this.latitude = resp.coords.latitude;
		 this.longitude = resp.coords.longitude;

		}).catch((error) => {
		  console.log('Error getting location', error);
		});

		// let watch = this.geolocation.watchPosition();
		// watch.subscribe((data) => {
		// 	this.latitude = data.coords.latitude
		//  	this.longitude = data.coords.longitude
		//  // data can be a set of coordinates, or an error (if an error occurred).
		//  // data.coords.latitude
		//  // data.coords.longitude
		// });

        this.nama_foto = year+""+month+""+day+""+hours+""+minutes+""+seconds+""+millisecond+""+this.nik;

  }

  getDate(){
  		var date = new Date();
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var day = date.getDate();
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();
        var millisecond = date.getMilliseconds();

        return year+"-"+month+"-"+day+" "+hours+":"+minutes
  }
   
	take(index_foto){
		let options: CameraOptions = {
		  quality: 100,
			allowEdit: true,
			saveToPhotoAlbum: true,
			correctOrientation: true,
			encodingType: this.camera.EncodingType.JPEG,
			destinationType: this.camera.DestinationType.FILE_URI
		}

		this.camera.getPicture(options).then((imageData) => {
		 // imageData is either a base64 encoded string or a file URI
		 // If it's base64 (DATA_URL):
		 let filename = imageData.substring(imageData.lastIndexOf('/')+1);
    	 let path =  imageData.substring(0,imageData.lastIndexOf('/')+1);
    	 

    	 this.file.readAsDataURL(path, filename).then((res)=>{
    	 	this.loading()
    	 	this.upload(filename,imageData,res,index_foto)

    // 	 	if(index_foto == "1"){
    // 	 		this.img1 = res
		 	// }else if(index_foto == "2"){
    // 	 		this.img2 = res
		 	// }else if(index_foto == "3"){
    // 	 		this.img3 = res
		 	// }else if(index_foto == "4"){
    // 	 		this.img4 = res
		 	// }else if(index_foto == "5"){
    // 	 		this.img5 = res
		 	// }else if(index_foto == "6"){
    // 	 		this.img6 = res
		 	// }else if(index_foto == "7"){
    // 	 		this.img7 = res
		 	// }

		 	// this.sendPostRequest(path,filename)
    	 	
    	 });


		 let base64Image = 'data:image/jpeg;base64,' + imageData;
		

		}, (err) => {
		 // Handle error
		});
	}

  ionViewDidLoad() {
    console.log('ionViewDidLoad FotoPage');
  }

  foto(x){
  	if(this.pilihan == "1"){
  		this.take(x)
  	}else{
  		this.fileGet(x)

  	}
  }

  sendPostRequest(data,nama){
     var link = 'http://alista.telkomakses.co.id/amalia/upload_base64_2.php';
     var myData = JSON.stringify({data: data,nama: nama});
     
     console.log(myData);
     this.http.post(link, myData)
     .subscribe(data => {
     	alert("sending success : "+data)
     }, error => {
      alert(error);
      // this.loader.dismiss();
     console.log("Oooops!");
     });
   }

   fileGet(index_foto){
      this.fileChooser.open()
          .then(uri => {
             this.filePath.resolveNativePath(uri)
            .then(filePath => {
              this.path = filePath;
              var nama_ori = filePath.split("/");
              var index_path  = nama_ori.length;
              if(
                nama_ori[index_path-1].indexOf(".jpg") > 0  || 
                nama_ori[index_path-1].indexOf(".jpeg") > 0 || 
                nama_ori[index_path-1].indexOf(".png") > 0 || 
                nama_ori[index_path-1].indexOf(".PNG") > 0 ||
                nama_ori[index_path-1].indexOf(".JPG") > 0 ||
                nama_ori[index_path-1].indexOf(".JPEG") > 0 ||
                nama_ori[index_path-1].indexOf(".pdf") > 0 ||
                nama_ori[index_path-1].indexOf(".PDF") > 0
                ){
                 this.nama_file = nama_ori[index_path-1];
		    	 let path =  filePath.substring(0,filePath.lastIndexOf('/')+1);
		    	 
		    	 this.file.readAsDataURL(path, this.nama_file).then((res)=>{
		    	 	this.loading()
		    	 	//this.img1 = res
		    	 	this.upload(this.nama_file,filePath,res,index_foto)
		    	 })
              }else{
                this.path = "-";
                this.nama_file = "-";
                //this.showPromptApp("File yang di perbolehkan {.jpg, .jpeg, .png, .PNG, .JPG, .JPEG, .pdf, .PDF}");
              }
            })
            .catch(err => {});
          })
          .catch(e => {});
    }

    upload(nama,path,res,index_foto){
      var options = {
        fileKey: "file",
        fileName: nama,
        chunkedMode: false,
        mimeType: "multipart/form-data",
        params : {'fileName': nama}
      };
     
      var url = "http://180.250.124.181/API/amalia/uploads.php";
      const fileTransfer: FileTransferObject = this.transfer.create();
      //Use the FileTransfer to upload the image
      fileTransfer.upload(path, url, options).then(data => {
      		this.loader.dismiss();
      		if(index_foto == "1"){
				this.img1 = res
				this.date_1 = this.getDate()
				this.lat_1 = this.latitude
				this.long_1 = this.longitude
				this.name_1 = nama
		 	}else if(index_foto == "2"){
    	 		this.img2 = res
				this.date_2 = this.getDate()
				this.lat_2 = this.latitude
				this.long_2 = this.longitude
				this.name_2 = nama
		 	}else if(index_foto == "3"){
    	 		this.img3 = res
				this.date_3 = this.getDate()
				this.lat_3 = this.latitude
				this.long_3 = this.longitude
				this.name_3 = nama
		 	}else if(index_foto == "4"){
    	 		this.img4 = res
				this.date_4 = this.getDate()
				this.lat_4 = this.latitude
				this.long_4 = this.longitude
				this.name_4 = nama
		 	}else if(index_foto == "5"){
    	 		this.img5 = res
				this.date_5 = this.getDate()
				this.lat_5 = this.latitude
				this.long_5 = this.longitude
				this.name_5 = nama
		 	}else if(index_foto == "6"){
    	 		this.img6 = res
				this.date_6 = this.getDate()
				this.lat_6 = this.latitude
				this.long_6 = this.longitude
				this.name_6 = nama
		 	}else if(index_foto == "7"){
    	 		this.img7 = res
				this.date_7 = this.getDate()
				this.lat_7 = this.latitude
				this.long_7 = this.longitude
				this.name_7 = nama
		 	}
      }, err => {});

    }


    showConfirm() {
    const confirm = this.alertCtrl.create({
      title: 'Gunaka Attach Foto?',
      message: '*bila menggunakan choose file di anjurkan menggunakan foto dari aplikasi GPS Camera',
      buttons: [
        {
          text: 'Foto Langsung',
          handler: () => {
            this.pilihan = "1";
            this.isian = 'ok';
          }
        },
        {
          text: 'Pilih Foto',
          handler: () => {
            this.pilihan = "2";
            
          }
        }
      ]
    });
    confirm.present();
  }

  loading(){
  	this.loader = this.loadingCtrl.create({
  		content: "please Wait.."
  	})
  	// execute loading 
  	this.loader.present();
  }

}
